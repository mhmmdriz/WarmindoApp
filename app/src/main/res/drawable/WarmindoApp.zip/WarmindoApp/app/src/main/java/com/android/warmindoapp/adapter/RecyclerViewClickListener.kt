package com.android.warmindoapp.adapter

public interface RecyclerViewClickListener {
  fun onEditClick(position: Int)
  fun onDeleteClick(position: Int)
}